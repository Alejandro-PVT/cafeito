"use client"

import { useState } from "react"

interface Product {
  id: number
  name: string
  description: string
  price: number | string
  image_url: string
  stock: number
  category_name?: string
}

interface ProductCardProps {
  product: Product
  onAddToCart: () => void
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const [imageError, setImageError] = useState(false)
  const isOutOfStock = product.stock === 0
  const price = typeof product.price === "string" ? Number.parseFloat(product.price) : product.price
  const displayPrice = isNaN(price) ? 0 : price

  const getCategoryQuery = () => {
    const categoryMap: Record<string, string> = {
      Café: "coffee",
      Pan: "bread",
      "Productos de Café": "coffee",
      "Café Molido": "coffee",
      Tazas: "mug",
      Accesorios: "coffee equipment",
    }
    return categoryMap[product.category_name || "Café"] || "coffee"
  }

  // Usando PlaceholderCo para imágenes de alimentos confiables
  const getFoodImageUrl = () => {
    const category = product.category_name?.toLowerCase() || "cafe"
    const randomId = Math.floor(Math.random() * 100)

    // URLs de imágenes públicas por categoría
    if (category.includes("pan")) {
      return `https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=400`
    } else if (category.includes("taza")) {
      return `https://images.pexels.com/photos/3813671/pexels-photo-3813671.jpeg?auto=compress&cs=tinysrgb&w=400`
    } else if (category.includes("molido")) {
      return `https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=400`
    }
    // Default café
    return `https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=400`
  }

  const imageUrl = imageError || !product.image_url ? getFoodImageUrl() : product.image_url

  return (
    <div className="cafeito-card overflow-hidden hover:shadow-lg transition">
      <div className="relative h-48 bg-muted overflow-hidden">
        <img
          src={imageUrl || "/placeholder.svg"}
          alt={product.name}
          className="w-full h-full object-cover"
          onError={() => setImageError(true)}
          crossOrigin="anonymous"
        />
        {isOutOfStock && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="text-white font-bold text-lg">Agotado</span>
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-bold text-lg mb-2">{product.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">{product.description}</p>

        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-primary">${displayPrice.toFixed(2)}</span>
          <button
            onClick={onAddToCart}
            disabled={isOutOfStock}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              isOutOfStock
                ? "bg-muted text-muted-foreground cursor-not-allowed"
                : "cafeito-button-secondary hover:bg-secondary/90"
            }`}
          >
            {isOutOfStock ? "Sin stock" : "Añadir"}
          </button>
        </div>
      </div>
    </div>
  )
}
